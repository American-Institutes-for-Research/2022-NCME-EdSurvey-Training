#' @title Preparing input files for `Dire::drawPVs` function by using `genData`.
#' @description Prepares the given objects for `genData` function. Where `gendata`
#' creates an `mml` input. Also delivers the other necessarry objects for `Dire`. 
#' Converts discrete variables to dummies, calculates correlation matrix, standard
#' deviations and thresholds. 
#' @param varGenDf a dataframe. Check `NAEPDataSimulation::varGenDf2005` as an
#' @param booklet NAEP booklet design. If `NULL`, the information will be carried 
#' out from NAEPirtparams::parameters based on the assessment information.
#' @param nStudent a numeric value indicating that the number of students will  
#' be generated in each school.
#' @param nSchool a numeric value indicating that the number of schools to be 
#' generated.
#' @param weights a list of two numeric vectors. The first one is for null
#' @param corMat matrix. If no input is giving, correlation matrix of 
#' NAEP primer will be used. This matrix should include all the correlations  
#' after discrete variables are converted to dummies.
#' @param seed set seed
#' @param sourceData `data.frame`, `edsurvey.data.frame` or `light.edsurvey.data.frame`.
#' The default is the NAEPprimer dataset.
#' @param thresholdDF threshold values for the categorical variables. If null,
#'  it will be calculated based on the `sourceData`.
#' @param sd_s Standard deviations (SD) of each variable. Note, SD should be
#' provided for every dummy variable for categorical datasets. If null, it will
#' be calculated based on the `sourceData`.
#' @param assessment A list of three. Desired NAEP assessment year, subject and 
#' level. The simulated data will be generated based on given irt parameters and
#'  matrix-samplig desing.
#' @param verbose if `TRUE`, provides the steps of the data generation process.
#' @importFrom EdSurvey readNAEP getData rebindAttributes getPlausibleValue
#' @importFrom stats na.omit
#' @export 
prepSimulation <- function(varGenDf,  booklet, nStudent = 20, nSchool = 10, weights = NULL, corMat = NULL, seed = 123, 
                           sourceData = readNAEP(system.file("extdata/data", "M36NT2PM.dat", package = "NAEPprimer")),
                           thresholdDF=NULL,
                           sd_s=NULL,
                           assessment = list(level = 8,
                                             subjects = 'Mathematics', 
                                             year =  2005),
                           verbose=TRUE){
  #Define the variable names
  varGenDfVars <- c("fileFormat", "variableName", "newVarType", "varType", "labelValues")
  for(vi in varGenDfVars) {
    if(!vi %in% colnames(varGenDf)) {
      stop(paste0("argument ", dQuote("varGenDf"), " must have a ", dQuote(vi), " column."))
    }
  }
  # check that the type is right
  if( any(varGenDf$fileFormat %!in% c("Student", "School", "State")) ) {
    stop(paste0("The ", dQuote("fileFormat"), " column of the ", dQuote("varGenDf"), " argument must take on only three levels: ", dQuote("Student"), ", ", dQuote("School"), " and ", dQuote("State")))
  }
  if( any(varGenDf$newVarType %!in% c("cat", "cont")) ) {
    stop(paste0("The ", dQuote("newVarType"), " column of the ", dQuote("varGenDf"), " argument must take on only two levels: ", dQuote("cat"), " and ", dQuote("cont")))
  }
  if( any(varGenDf$varType %!in% c("b", "c", "m")) ) {
    stop(paste0("The ", dQuote("varType"), " column of the ", dQuote("varGenDf"), " argument must take on only three levels: ", dQuote("b"), ", ",dQuote("c") , " and ", dQuote("m")))
  }
  #Define the weights based on the imitation
  if (is.null(weights)) {
    w1 <- "origwt" #student level weight variable
    w2 <- "smsrswt"
  } else {
    if(length(weights) != 2) {
      stop("there must be two weights, the first for students, the second for schools.")
    }
    if(!inherits(weights, "character")) {
      stop("weights must be a character vector.")
    }
    w1 <- weights[[1]]
    w2 <- weights[[2]]
  }
  
  # find student and school varialbes
  stuVar <- subset(varGenDf, fileFormat == "Student", "variableName", drop=TRUE) #student level variables
  stuVarCont <- subset(varGenDf, variableName %in% stuVar & newVarType %in% "cont", "variableName", drop=TRUE)
  schVar <- subset(varGenDf, fileFormat == "School", "variableName", drop=TRUE)
  schVarCont <- subset(varGenDf, variableName %in% schVar & newVarType %in% "cont", "variableName", drop=TRUE)
  # find binary variables
  binary <- subset(varGenDf, varType %in% "b", "variableName", drop=TRUE)
  catVar <- subset(varGenDf, newVarType %in% "cat", "variableName", drop=TRUE)
  contVar <- subset(varGenDf, newVarType %in% "cont", "variableName", drop=TRUE)
  plausibleValues <- subset(varGenDf, labelValues %in% "PV", "variableName", drop=TRUE)
  contextVar <- c(schVar, stuVar)[c(schVar, stuVar) %!in% plausibleValues] #contextual variables on the both levels
  p_sch <- length(schVar)        #number of school covariates
  
  #Determine the dummy names
  k <- 1
  dummyNames <- vector(mode="character") #dummy names 2+ categories
  #dummyNames
  if(verbose) {
    message("Generating dummy variable names")
  }
  for(cV in contextVar){
    if(varGenDf[varGenDf$variableName == cV, "newVarType"] == "cat"){
      thisCol <- sourceData[ , cV]
      if( inherits(thisCol, "factor") ) {
        lvls <- levels(thisCol)
      } else {
        lvls <- sort(unique(thisCol))
      }
      # and NA if there is any
      if(any(is.na(thisCol))) {
        lvls <- c(lvls, NA)
      }
      for(l in lvls){
        dummyNames[k] <- paste0(cV, "_", l) 
        k <- k+1
      }
    }
  }
  
  #update the school an student variables with new dummy names
  schVarDummy <- dummyNames[vapply(strsplit(dummyNames, "_"), `[`, 1, FUN.VALUE=character(1)) %in% schVar]
  stuVarDummy <- dummyNames[vapply(strsplit(dummyNames, "_"), `[`, 1, FUN.VALUE=character(1)) %in% stuVar]
  
  #TODO we need to give a generic path name
  if(verbose) {
    message("Converting discrete variables to dummies")
  }
  sourceDataNew <- getData(sourceData,
                           varnames = c(contextVar, stuVarCont, schVarCont, "origwt", "smsrswt", "scrpsu"),
                           omittedLevels=FALSE,  # include rows even if they have 1 or more NAs
                           dropUnusedLevels=FALSE) # keep unused levels
  for(cV in catVar){
    sourceDataNew <- convertDummy(sourceDataNew, cV = cV)
  }
  sourceDataNew <- rebindAttributes(sourceDataNew, sourceData)
  
  corMatrixNames0 <- corMatrixNames <- c(dummyNames, stuVarCont, schVarCont)
  # renamed to a single PVs name
  plausibleValuesPrime <- plausibleValues 
  contVarPrime <- contVar
  for(i in seq_along(plausibleValues)) {
    newVarName <- getPlausibleValue(data=sourceDataNew, plausibleValues[i])[1]
    corMatrixNames[corMatrixNames == plausibleValues[i]] <- newVarName
    plausibleValuesPrime[i] <- newVarName
    contVarPrime[contVar %in% plausibleValues[i]] <- newVarName
  }
  
  if (is.null(corMat)) {
    if(verbose) {
      message("Calculating correlation matrix.")
    }
    a <- length(corMatrixNames)
    corMatrix <- data.frame(matrix(NA, nrow=a, ncol=a, dimnames=list(corMatrixNames, corMatrixNames)))
    # data.frame "fixes" names, fix them back
    colnames(corMatrix) <- corMatrixNames
    for(i in 1:(a-1)){
      var1 <- corMatrixNames[i]
      for(j in (i+1):a){
        var2 <- corMatrixNames[j]
        xy <- sourceDataNew[,c(var1, var2, "origwt")]
        xy <- na.omit(xy)
        if(length(unique(xy[,1])) >= 2 & length(unique(xy[,2])) >= 2) {
          corMatrix[var2, var1] <- corMatrix[var1, var2] <- wCorr::weightedCorr(x=xy[,1], y=xy[,2], weights=xy[,3], method = "Pearson")
        } else {
          corMatrix[var2, var1] <- corMatrix[var1, var2] <- 0
        }
      }
    }
  }
  diag(corMatrix) <- 1
  if(is.null(sd_s)) {
    if(verbose) {
      message("Calculating sd_s vector")
    }
    sd_s <- vector(mode="numeric", length(corMatrixNames))
    names(sd_s) <- corMatrixNames
    for(thisVar in corMatrixNames){
      if(thisVar %in% contVarPrime){
        if(thisVar %in% plausibleValuesPrime) {
          sd_s[thisVar] <- 1 #this now represents a theta score, so it can just be one
        } else {
          sd_s[thisVar] <- wsd(sourceDataNew[,thisVar], sourceDataNew[,w1])
        }
      } else { #if not continuous it is a categorical so it will be dummy
        sd_s[thisVar] <- 1 #if it is categorical we will just give 1 for SD
      }
    }
  }
  if(is.null(thresholdDF)) {
    #Calculate thresholds
    thresholdDF <- matrix(data = NA, ncol = length(dummyNames), nrow = 1)
    if(verbose) {
      message("Calculating the thresholds vector")
    }
    colnames(thresholdDF) <- dummyNames
    for(cV in dummyNames){
      thresholdDF[,cV] <- threshold(sourceDataNew[,cV])
    }
  }
  schid <- sourceDataNew$scrpsu
  
  correlations <- formatCorMatrix(corMatrix, schVarDummy, stuVarDummy, sd_s, thresholdDF)
  # fix PV variable names back to plausible value
  colnames(correlations$cov_matrix) <- colnames(correlations$corMat) <- corMatrixNames0
  rownames(correlations$cov_matrix) <- rownames(correlations$corMat) <- corMatrixNames0
  m1 <- rep(0, length(c(stuVarDummy, stuVarCont)))
  m2 <- rep(0, length(c(schVarDummy, schVarCont)))
  mmlArgs <- genData(correlations$corMat, correlations$cov_matrix, correlations$l1_thr, correlations$l2_thr, nStudent, 
                     m1, m2, contextVar, nSchool, seed,
                     booklet, assessment, p_sch, schVar, stuVar, 
                     schVarDummy, stuVarDummy, thresholdDF, contVar, catVar, stuVarCont, schVarCont)
  return(mmlArgs)
}


formatCorMatrix <- function(corMat, schVarDummy, stuVarDummy, sd_s, thresholdDF) {
  #Turns cor matrix into cov matrix
  corMatrixNames <- colnames(corMat)
  if( any(colnames(corMatrixNames) %!in% corMatrixNames)) {
    stop("sd_s must contains all variables in corMatrixNames")
  }
  sd_s <- sd_s[corMatrixNames]
  cov_matrix <- diag(sd_s) %*% as.matrix(corMat) %*% diag(sd_s)
  colnames(cov_matrix) <- rownames(cov_matrix) <- corMatrixNames 
  
  #thresholds for level 2 variables
  l2_thr <- thresholdDF[,schVarDummy]
  l1_thr <- thresholdDF[,stuVarDummy]
  corr_info <- structure(list("corMat" = as.matrix(corMat), "cov_matrix" = as.matrix(cov_matrix), "l1_thr"  = l1_thr, "l2_thr" = l2_thr), 
                         class=c("NDScorrelation"))
  return(corr_info)
}
