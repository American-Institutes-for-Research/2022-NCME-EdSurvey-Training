#' @title genPVs function
#' @description Draws plausible values for the simulated dataset.
#' @param mmlArgs a list of mmlArguments. 
#' @param npv an integer. Number plasuible values to be generated.
#' @importFrom Dire mml drawPVs
#' @export
genPVs <- function(mmlArgs, npv=20) {
  sim_dat <- mmlArgs$stuDat
  if(!"idVar" %in% colnames(sim_dat)) {
    stop(paste0("sim_dat argument must have a column named ", dQuote("idVar"), " for the merge to work."))
  }
  mmlObj <- do.call(mml, mmlArgs)
  
  PVs <- drawPVs(mmlObj, npv = npv)
  colnames(PVs$data)[1] <- "idVar"
  final_generated_data <- merge(sim_dat, PVs$data, by = "idVar")
  #rename the PVs
  subtest <- mmlArgs$testScale$subtest
  for(sb in seq_along(subtest)){
    names(final_generated_data)[grep(subtest[sb], names(final_generated_data))] <- 
      paste("MRPS",sb,sapply(strsplit(names(final_generated_data)[grep(subtest[sb], names(final_generated_data))], "_dire"), "[", 2), sep = "")
  }
  names(final_generated_data)[grep("composite", names(final_generated_data))] <- 
    paste("MRPCM",sapply(strsplit(names(final_generated_data)[grep("composite", names(final_generated_data))], "_dire"), "[", 2), sep = "")
  return(final_generated_data)
}
