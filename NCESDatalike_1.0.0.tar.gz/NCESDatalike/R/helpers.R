# find a matrix nearby that is positive definite, only if needed; issue a warning when needed
nearPD2 <- function(X, tol=400) {
  eig <- eigen(X)
  if(min(eig$values) <= 0 || max(eig$values)/min(eig$values) >= 1/((.Machine$double.eps)^0.25)) {
    warning("Numerical instability in estimating the standard error of variance terms. Consider the variance term standard errors approximate.")
    X <- Matrix::nearPD(X, posd.tol=tol*sqrt(.Machine$double.eps))$mat
  }
  return(X)
}

# add not in function
'%!in%' <- function(x,y)!('%in%'(x,y)) #https://stackoverflow.com/questions/5831794/opposite-of-in-exclude-rows-with-values-specified-in-a-vector

#Turn to dummy - I turn dummy to all categorical variables and chose the ones later
#' @title convertDummy function
#' @description Turn to dummy - I turn dummy to all categorical variables and chose the ones later
#' @param dat insert description
#' @param cV insert description
convertDummy <- function(dat, cV){
  lvls <- levels(dat[,cV]) #use summary to capture the NAs
  if(any(is.na(dat[,cV]))) {
    lvls <- c(lvls, NA)
  }
  for(l in lvls){
    y <- paste0(cV,"_",l)
    dat[,y] <- ifelse(dat[ , cV] %in% l, 1, 0) #using %in% correctly handles NA values
  }
  return(dat)
}

# identify threshold for binary variable; portions from from wCorr, author Paul Bailey
#' @importFrom stats sd qnorm
threshold <- function(dat){
  if(sd(dat) == 0){
    thr <- Inf
  } else {
    M <- as.numeric(as.factor(dat))
    uM <- sort(unique(M))
    thr <- sapply(uM[-length(uM)], function(z) qnorm( mean(M<=z) ) )
  }
  return(thr)
}

# weighted standard deviation; portions from EdSurvey, author Paul Bailey
wsd <- function(x, w) {
  wx <- data.frame(x=x,w=w)
  wx <- na.omit(wx)
  w <- wx$w
  x <- wx$x
  mu <- sum(w * x)/sum(w)
  vari <- sum(w * (x - mu)^2)/(sum(w))
  return(vari)
}

#var: original name under the sdf
#varDummy: dummy names
categorizeDummy <- function(var, varDummy, data_latent, thresholdVec){
  dummyCat <- varDummy[grep(var, varDummy)]
  catNames <- gsub(paste0(var,"_"),"",dummyCat)
  catNames2 <- vapply(strsplit(dummyCat, "_"), `[`, 2, FUN.VALUE=character(1))
  if( any(catNames %!in% catNames2) ) {
    cat("bad cat names from gsub\n")
    browser()
  }
  varLatent <- data_latent[ , dummyCat, drop=FALSE] #latent variables for each dummy
  thr <- thresholdVec[dummyCat]
  #for(i in 1:ncol(varLatent)){
  #  if(thr[[i]] %in% c(Inf)) {
  #    temp <- factor(rep(1, nrow(varLatent)),levels=c(0,1))
  #  }
  #  if(thr[[i]] %in% c(-Inf)) {
  #    temp <- factor(rep(0, nrow(varLatent)),levels=c(0,1))
  #  }
  #  temp <- factor(cut(varLatent[ , i], breaks = c(-Inf, thr[[i]], Inf)), 
  #                 levels = c(paste0("(-Inf,",round(thr[[i]],3),"]"), #I had to add this because some of the dummies have only one value
  #                            paste0("(",round(thr[[i]],3),", Inf]")))
  #  levels(temp) <- c(0,1)
  #}
  varCat <- t(t(varLatent) - thr)
  finalDecision <- factor(colnames(varLatent)[apply(varCat, 1, which.max)], levels = dummyCat,
                          labels = gsub(paste0(var,"_"), "", dummyCat))
  return(finalDecision)
}

