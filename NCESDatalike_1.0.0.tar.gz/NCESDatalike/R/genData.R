#' @title Generating `mml` input for `Dire::drawPVs` function.
#' @description Creates an `mml` input. Generates student data conditioned on
#' school dataset. Returns generated background data in wide format and student
#' responses in a long format, along with all other necessary `Dire::mml` inputs. 
#' @param corMat matrix. It should include all the correlations after discrete 
#' variables are converted to dummies.
#' @param cov_matrix matrix. It should include all the variance and covariances 
#' after discrete variables are converted to dummies.
#' @param l1_thr a numeric vector including , contains threshold values for all 
#' categories of level 1 dataset for all variables, including dummies.  
#' @param l2_thr a numeric vector, contains threshold values for all categories 
#' of level 2 dataset for all variables, including dummies. 
#' @param nStudent an integer. Number of students in each school.
#' @param m1 a numeric vector, contains student level variables mean value; set 
#' to zero for categorical variables
#' @param m2 a numeric vector, contains school level variables mean value; set 
#' to zero for categorical variables
#' @param contextVar a character vector contains the name of the background 
#' variables
#' @param nSchool an integer. Number of schools to be generated.
#' @param seed set seed.
#' @param booklet booklet design for matrix sampling design. If `NULL` it will
#' be drawn from `NAEPirtparams::bookletDesign`.
#' @param assessment A list of three. Desired NAEP assessment year, subject and 
#' level. 
#' @param p_sch number of school level background variables.
#' @param schVar a character vector contains school level background variables.
#' @param stuVar a character vector contains school level background variables.
#' @param schVarDummy  a character vector contains school level background 
#' variables dummy names.
#' @param stuVarDummy  a character vector contains student level background 
#' variables dummy names.
#' @param thresholdDF a dataframe or matrix containing the thresholds for each 
#' dummy variable.
#' @param contVar a character vector contains name of the continuous variables.
#' @param catVar a character vector contains name of the categorical variables.
#' @param stuVarCont a character vector contains name of the student level 
#' continuous variables.
#' @param schVarCont a character vector contains name of the school level
#' continuous variables.
#' @param PSUperStrata an integer indicating how many PSUs per strata.
#' @param schoolsPerPSU  an integer indicating how many schools per PSU
#' @param nSchoolPop an integer. Generated school population for weighting. 
#' @param verbose if `TRUE`, provides the steps of the data generation process.
#' @importFrom stats as.formula rnorm reshape
#' @export
genData <- function(corMat, cov_matrix, l1_thr, l2_thr, nStudent, 
                    m1, m2, contextVar, nSchool,  seed=2, 
                    booklet, assessment, p_sch, schVar, stuVar,
                    schVarDummy, stuVarDummy, thresholdDF, contVar, catVar, stuVarCont, schVarCont,
                    PSUperStrata=2, schoolsPerPSU=2, nSchoolPop=50000, verbose=TRUE){
  if(verbose) {
    message("Generating school data")
  }
  #1) School level data generation
  uncor_mat_l2 <- matrix(NA, nrow = nSchoolPop, ncol =  length(schVarDummy))
  set.seed(seed)
  # for every student variable make iid latent data
  for (clmn in 1:length(schVarDummy)) {
    uncor_mat_l2[, clmn] <- rnorm(nSchoolPop, 0, 1)
  }
  # now correlate that data using the squareroot matrix
  # TODO: document the formula you are using and add a reference
  schGenVar <- c(schVarDummy, schVarCont)
  chol_corMat_l2 <- chol(nearPD2(corMat[schGenVar,schGenVar]))
  school_data_latent <- uncor_mat_l2 %*% chol_corMat_l2
  school_data <- school_data_latent
  colnames(school_data) <- colnames(school_data_latent) <- schVarDummy
  # sample schools
  # the "prob" argument could be used to adjust weights according to demographics
  school_data <- as.data.frame(as.matrix(school_data))
  pr <- rep(1, nrow(school_data))
  pr <- pr/sum(pr)
  school_data$sampProb <- pr
  school_data <- school_data[smp <- sample(1:nrow(school_data), nSchool, replace=FALSE, prob=school_data$sampProb), ]
  school_data_latent <- school_data_latent[smp, ]
  school_data$wsch <- (1/school_data$sampProb) / nSchool
  school_data$sampProb <- NULL
  #2) Generate student level data based on the conditional distribution
  
  # TODO: do not use implicit variables, fix all the calls so that they work with these explicit variables
  # https://en.wikipedia.org/wiki/Multivariate_normal_distribution#Conditional_distributions for the equations
  mubar <- function(a, m1, sigma12, sigma22, m2){
    return(m1 + sigma12 %*% MASS::ginv(sigma22) %*% (a - m2)) #is it correct for the generalized inverse
  }
  # TODO: document what this function is for
  sigmabar <- function(sigma11, sigma12, sigma22){
    sigma21 <- t(sigma12)
    return(sigma11 - sigma12 %*% MASS::ginv(sigma22) %*% sigma21)
  }
  stuGenVar <- c(stuVarDummy, stuVarCont) #variables that will be generated on the student level
  sigma11 <- cov_matrix[stuGenVar, stuGenVar] #var-cov matrix of l1 var - qxq matrix
  sigma22 <- cov_matrix[schGenVar, schGenVar] #var-cov matrix of l2 var - N-q x N-q matrix
  
  sigma12 <- cov_matrix[stuGenVar, schGenVar] #var-cov matrix of l1 and l2
  sigma21 <- cov_matrix[schGenVar, stuGenVar] #var-cov matrix of 
  # TODO: what is sigma_bar?
  sigma_bar <- sigmabar(sigma11, sigma12, sigma22)
  
  #now generate the dataset for each school
  generated_data <- list()
  # setup variables we will count along
  
  # for each school
  student_data_temp <- as.data.frame(matrix(NA, nrow = nStudent*nSchool, ncol = length(stuGenVar), dimnames = list(c(), stuGenVar)))
  student_data_temp$schId <- rep(1:nSchool, each = nStudent)
  school_data$schId <- 1:nSchool
  
  if(verbose) {
    message("Generating student data")
  }
  for(i in 1:nSchool){
    # NOTE: this was profoundlty confusing! you cannot use catagorized school_dataa, you need uncatagorized data.
    # mu_bar is the mean of the student variables conditional on the school-evel
    mu_bar <- mubar(school_data_latent[i, ], m1, sigma12, sigma22, m2)
    student_data_temp[student_data_temp$schId == i,stuGenVar] <- MASS::mvrnorm(nStudent, mu_bar, Sigma = sigma_bar)
  }
  
  psu <- 1
  stratum <- 1
  psuSchooli <- 1
  
  for(i in 1:nSchool){
    school_data$repgrp1[i] <- stratum 
    school_data$jkunit[i] <- psu
    school_data$origwt[i] <- school_data$wsch[i] * 2
    # incriment these according to our rules
    psuSchooli <- psuSchooli + 1
    if(psuSchooli > schoolsPerPSU) {
      # incriment psu; set psuSchooli back to one
      psu <- psu + 1
      psuSchooli <- 1 
      if(psu > PSUperStrata) {
        # incriment stratum; set PSU back to one
        stratum <- stratum + 1
        psu <- 1 
      }
    }
  }
  
  zipCodes <- NCESDatalike::zipCodes
  school_data$zip <- sample(zipCodes$zip, nSchool)
  school_data$fips <- merge(school_data, zipCodes[,c("zip", "fips")], by = c("zip"))$fips
  school_data$acsVar <- abs(rnorm(nSchool, mean=10000, sd=5000))
  generatedLatentData <- merge(school_data, student_data_temp, by = "schId")
  
  #categorize the dataset here
  generatedData <- matrix(NA, nrow = nrow(generatedLatentData), ncol = length(catVar))
  colnames(generatedData) <- catVar
  generatedData <- as.data.frame(generatedData)
  if(verbose) {
    message("Converting latent values into categories")
  }
  for(thisVar in catVar){
    generatedData[,thisVar] <- categorizeDummy(thisVar, c(schVarDummy,  stuVarDummy), generatedLatentData, thresholdVec = c(l1_thr, l2_thr))
  }
  copyVars <- c("wsch", "schId", "repgrp1", "jkunit", "origwt", stuVarCont, schVarCont, "zip", "fips")
  for(var in copyVars){
    generatedData[,var] <- generatedLatentData[,var]
  }
  
  generatedData$stuId <- as.character(1e+7+1:nrow(generatedData))
  
  #Call NAEP item parameters
  param <- NAEPirtparams::parameters
  #TODO: if param$block is NA, give warning "Block information does not exist, select another assessment"
  booklet <- NAEPirtparams::bookletDesign
  item_par <- param[param$level == assessment$level & param$subject == assessment$subjects & param$year == assessment$year, ]
  booklet <- booklet[booklet$level == assessment$level & booklet$subject == assessment$subjects & booklet$year == assessment$year, ]
  paramTabs <- naepParamTabs(item_par)
  subscales <- levels(factor(item_par$subtest))
  item_par$item <- item_par$NAEPid
  
  polyParamTab <- paramTabs$polyParamTab
  dichotParamTab <- paramTabs$dichotParamTab
  
  dimensions <- list()
  for(i in subscales){
    dimensions[[i]] <- subset(item_par, subtest == i)
  }
  #TODO:  what is cog_items? why declare it here?
  cog_items <- list()
  
  thetas <- stuVarCont
  if(length(thetas) != length(subscales)){
    stop("Number of thetas and subscales are different")
  }
  
  if(verbose) {
    message("Generate cognitive items")
  }
  for(k in seq_along(subscales)) {
    thisScale <- subscales[k]
    cog_items[[thisScale]] <- gen_cog_items(item_par = dimensions[[thisScale]], booklet = booklet, 
                                            background_data = generatedData, N = nSchool*nStudent,
                                            theta = thetas[k])
  }
  cog_items <- do.call("cbind", cog_items)
  nm <- names(cog_items)
  nm <- do.call(rbind,strsplit(nm, "[.]"))[,2]
  colnames(cog_items) <- nm
  # add cognitive items to generated data
  
  #Prepare stuItems
  cog_items_low <- cog_items
  names(cog_items_low) <- tolower(names(cog_items_low))
  cog_items_low$idVar <- generatedData$stuId
  idVar <- generatedData$stuId
  
  stuItems <- reshape(cog_items_low, idvar = "idVar", direction = "long", v.names = "score",
                      timevar = "key", times = c(polyParamTab$ItemID,dichotParamTab$ItemID),
                      varying = c(polyParamTab$ItemID,dichotParamTab$ItemID))
  rownames(stuItems) <- NULL
  #Prep stuDat
  #TODO add weight var, stratavar and psuvar
  indepVars <- contextVar[contextVar%!in%thetas]
  new_dat <- generatedData
  new_dat$idVar <- as.character(new_dat$stuId)
  sampVars <- c("repgrp1", "jkunit", "origwt", "wsch")
  stuDat <- new_dat[,c("idVar", indepVars, sampVars, "zip", "fips")]    
  stuDat <- merge(stuDat, cog_items_low, by = "idVar")
  #Prepare  testDat
  transf <- NAEPirtparams::transformations
  transFilter <- transf[transf$level== assessment$level & transf$year== assessment$year & 
                          transf$subject== assessment$subjects & transf$assessmentCode != "State" &
                          transf$accommodations != "accom", ]
  testDat <- transFilter[,c('subtest','location','scale', 'subtestWeight')]
  testDat <- testDat[!is.na(testDat$subtestWeight),]
  if((round(sum(testDat$subtestWeight), 1)==1) & (nrow(testDat)>1)){
    # if weights add up to 1, this is a composite test
    testDat$test <- 'composite'
    if (nrow(dichotParamTab) > 0) {
      dichotParamTab$test <- 'composite'
    }
    if (nrow(polyParamTab) > 0) {
      polyParamTab$test <- 'composite'
    }
  } else {
    # this is not a composite test
    testDat$test <- testDat$subtest
    dichotParamTab$test <- testDat$subtest
    polyParamTab$test <- testDat$subtest
    testDat$subtest <- NULL
    dichotParamTab$subtest <- NULL
    polyParamTab$subtest <- NULL
  }
  
  # check that there are enough d's for polyParamTab max scorePoints
  polyParamTab$scorePoints <- apply(polyParamTab[,c('d1','d2','d3','d4','d5')], 1, function(x) 5 - sum(is.na(x)))
  if(verbose) {
    message("pop size: ", format(round(sum(stuDat$origwt)), scientific=FALSE, big.mark=",", big.interval=3),"\n")
  }
  # return arguments 
  return(structure(list("formula" = as.formula("composite ~ 1"),
                        "stuItems" = stuItems,
                        "stuDat" = stuDat,
                        "idVar" = "idVar",
                        "dichotParamTab" = dichotParamTab,
                        "polyParamTab" = polyParamTab,
                        "testScale" = testDat,
                        "Q" = 34,
                        "composite" = TRUE,
                        "minNode" = -4,
                        "maxNode" = 4,
                        "strataVar" = NULL,
                        "PSUVar" = NULL,
                        "weightVar" = NULL,
                        "fast" = TRUE,
                        "multiCore" = FALSE,
                        "verbose"=2),
                   class=c("mmlArgs")))
}
