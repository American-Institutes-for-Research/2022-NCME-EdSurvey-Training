naep_matrix_design <- function(item_par, booklet){
  ib_matrix <- matrix(nrow = nrow(item_par), ncol = nrow(booklet), dimnames = list(item_par$item, booklet$Booklet_number))
  for(i in 1:nrow(booklet)){
    a <- subset(item_par, block == booklet$Cog_b1[i] | block ==  booklet$Cog_b2[i])[,"item"]
    ib_matrix[,i] <- as.numeric(item_par$item %in% a)
  }
  return(ib_matrix)
}
