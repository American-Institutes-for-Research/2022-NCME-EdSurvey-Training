#' NAEP data
#' 
#' This data table contains NCES NAEP ...
#' #'
#'
#' @format A data frame with columns
#' \describe{
#'  \item{variableName}{}
#'  \item{Labels}{}
#'  \item{labelValues}{}
#'  \item{fileFormat}{}
#'  \item{varType}{}
#'  \item{newVarType}{}
#' }
#' @references NAEP Primer
#'
"varGenDf2015"
