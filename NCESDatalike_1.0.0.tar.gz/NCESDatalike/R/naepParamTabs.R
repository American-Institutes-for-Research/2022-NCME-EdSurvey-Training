#' NAEP Irt Parameters separator
#' from EdSurvey but not exported 
#' Author: Sun-joo Lee
#'
#' @param params_use NAEPirtparams::parameters object.
#' 
#' @return A list of dichotomous and polytomous items.
#' @export
#'
#' @examples
#' params <- NAEPirtparams::parameters
#' naepParamTabs(params)

naepParamTabs <- function(params_use) {
  paramTabs <- list()
  # polyParamTab
  poly <- params_use[!is.na(params_use$d1),]
  polyParamTab <- poly[, colnames(poly)[!colnames(poly) %in% c('c')]]
  polyParamTab <- polyParamTab[, c('NAEPid','subtest', 'a','b',paste0('d',1:5))]
  colnames(polyParamTab) <- c('ItemID','subtest', 'slope', 'itemLocation', paste0('d',1:5))
  polyParamTab$ItemID <- tolower(polyParamTab$ItemID)
  if (nrow(polyParamTab) > 0) {
    polyParamTab$D <- 1.7
    polyParamTab$missingValue <- 'c'
    polyParamTab$missingCode <- 8
  }
  
  # dichotomous
  bi <- params_use[!params_use$NAEPid %in% poly$NAEPid,]
  dichotParamTab <- bi[, colnames(bi)[!colnames(bi) %in% paste0('d',1:5)]]
  dichotParamTab <- dichotParamTab[, c('NAEPid','subtest', 'a','b','c')]
  colnames(dichotParamTab) <- c('ItemID', 'subtest', 'slope', 'difficulty', 'guessing')
  dichotParamTab$ItemID <- tolower(dichotParamTab$ItemID)
  if (nrow(dichotParamTab) > 0) {
    dichotParamTab[is.na(dichotParamTab$guessing), 'guessing'] <- 0
    dichotParamTab$D <- 1.7
    dichotParamTab$missingValue <- 'c'
    dichotParamTab$missingCode <- 8
  }
  paramTabs$polyParamTab <- polyParamTab
  paramTabs$dichotParamTab <- dichotParamTab
  
  return(paramTabs)
} 
