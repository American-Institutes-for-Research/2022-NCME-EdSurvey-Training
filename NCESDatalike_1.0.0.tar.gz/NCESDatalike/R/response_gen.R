#' @importFrom lsasim irt_gen
updated_response_gen <- function(subject, item, theta, a_par = NULL, 
                                 b_par, c_par = NULL, d_par = NULL, 
                                 item_no = NULL, ogive = "Logistic"){
  if (length(subject) != length(item)) {
    stop("subject and item vectors must be equal length.", call. = FALSE)
  }
  if (length(unique(item)) > length(b_par)) {
    stop("Must include b_par for each item.", call. = FALSE)
  }
  if (!is.null(a_par) & length(unique(item)) != length(a_par)) {
    stop("Must include a parameter for each item.", call. = FALSE)
  }
  if (!is.null(c_par) & length(unique(item)) != length(c_par)) {
    stop("Must include c parameter for each item.", call. = FALSE)
  } 
  if (ogive %!in% c("Normal", "Logistic")) {
    stop("ogive must be Normal or Logistic.", call. = FALSE)
  } 
  
  if (is.null(a_par)) a_par <- rep(1, length(unique(item)))
  if (is.null(c_par)) c_par <- rep(0, length(unique(item)))

  if (ogive == "Logistic") DD <- 1
  if (ogive == "Normal") DD <- 1.7

  if (is.null(item_no)) item_no <- seq(length(unique(item))) #unique(item) 


  #--- construct b_pars list to be used in irt_gen() --------------------------# 
  if (is.null(d_par)) b_pars <- split(b_par, seq(length(b_par)))

  if (!is.null(d_par)) { 
    d_mat <- do.call("cbind", d_par)
    b_pars <- list()
    n_cat <- rowSums(apply(d_mat, 2, function(x) !is.na(x)))
    
  for (i in 1:length(b_par)){
    if(n_cat[i]==0){
      b_pars[[i]] <- b_par[i]
    } else {
        b_list <- list()
        for (j in 1:length(na.omit(d_mat[i, ]))) b_list[[j]] <- b_par[i] + d_mat[i, j]
        b_pars[[i]] <- unlist(b_list)
      } 
  }  
  }
  names(b_pars) <- item_no
  #----------------------------------------------------------------------------#
  y <- numeric(length(subject))
  c_par[is.na(c_par)] <- 0
  for (n in 1 : length(subject)) {
    y[n] <- irt_gen(theta = theta[subject[n]], 
                    a_par = a_par[item[n]], 
                    b_par = b_pars[[item[n]]],
                    c_par = c_par[item[n]],
                    D     = DD)
  }

  df_l <- data.frame(item = item, subject = subject, response = y)

  df_w <- reshape(df_l, timevar = "item", idvar = "subject", direction = "wide")

  # This could be better generalized to respond to the number of digits.
  df_item_old <- colnames(df_w)[2:length(df_w)]
  df_item_num <- gsub("[^[:digit:]]", "", df_item_old)
  df_item_new <- ifelse(nchar(df_item_num) == 1, paste0("i00", df_item_num), 
                   ifelse(nchar(df_item_num) == 2, paste0("i0", df_item_num),
                     paste0("i", df_item_num)))

  colnames(df_w)[2:length(df_w)] <- df_item_new
  df_w <- df_w[, order(names(df_w))]
  rownames(df_w) <- NULL
  return(y = df_w)
}

