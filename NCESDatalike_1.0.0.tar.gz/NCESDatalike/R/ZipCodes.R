#' The US Zip Codes
#' 
#' This data table contains zip codes in the US
#' #'
#'
#' @format A data frame with columns
#' \describe{
#'  \item{population}{}
#'  \item{fips}{}
#'  \item{zip}{}
#' }
#' @references  "https://api.census.gov/data/2019/acs/acs5?get=NAME,B01001_001E&for=zip%20code%20tabulation%20area:*&in=state:*"
#'
"zipCodes"
