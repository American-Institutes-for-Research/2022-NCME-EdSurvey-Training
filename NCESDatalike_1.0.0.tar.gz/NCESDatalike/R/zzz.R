globalVariables(c("block","subtest","fileFormat", "variableName",
                  "newVarType", "varType", "labelValues"))