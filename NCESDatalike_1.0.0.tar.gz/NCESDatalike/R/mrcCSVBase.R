if(FALSE){
#mrcCSV file prep
#only run if mrcFileCSV.csv is missing
require(NAEPprimer)
mrcFile <- readLines(system.file("extdata/select/parms","M36NT2PM.fr2", package = "NAEPprimer"))
if( any(nchar(mrcFile) < 90) ) {
  stop(paste0("Malformed fr2 file: some lines have fewer than the required 90 characters. Lines ", pasteItems(which(nchar(mrcFile)<90)), "."))
}
variableName <- trimws(substring(mrcFile, 1, 8)) # name of the variable
Start <- as.numeric(trimws(substring(mrcFile, 9, 12))) # start column in file
Width <- as.numeric(trimws(substring(mrcFile, 13, 14))) # numshowber of characters in variable
End <- Start + Width -1 # end column in file
Decimal <- as.numeric(trimws(substring(mrcFile, 15, 15))) # digits (from the right) to be considered decimals
Labels <- trimws(substring(mrcFile, 21, 70)) # variable label
NumValue <- as.numeric(trimws(substring(mrcFile, 89, 90))) # number of numeric codes (e.g. one could would be 1="Yes")
zeroLenVars <- nchar(variableName) == 0
if(any(zeroLenVars)) {
  warning(paste0("Unnamed variables in .fr2 file on row(s) ", pasteItems( (1:length(variableName))[zeroLenVars]), ". File located at ", filename, ". These variables renamed sequentially, starting with V1."))
  variableName[zeroLenVars] <- paste0("v", 1:sum(zeroLenVars))
}

zeroLenVars <- nchar(variableName) == 0
if(any(zeroLenVars)) {
  warning(paste0("Unnamed variables in .fr2 file on row(s) ", pasteItems( (1:length(variableName))[zeroLenVars]), ". File located at ", filename, ". These variables renamed sequentially, starting with V1."))
  variableName[zeroLenVars] <- paste0("v", 1:sum(zeroLenVars))
}
# parse the numeric codes
labelValues <- character(length(mrcFile))
for (j in 1:length(mrcFile)) {
  # for each line:
  Ncodes <- NumValue[j]-1
  if (Ncodes > 0) {
    # if it has numeric codes
    # read in up to 26 character per code, plus 2 characters for the number
    codeValSeq <- seq(91, (91+Ncodes*28), by = 28)
    codeLabelSeq <- seq(93, (93+Ncodes*28), by = 28)
    values <- as.numeric(trimws(substring(mrcFile[j], codeValSeq, codeValSeq+1)))
    labels <- trimws(substring(mrcFile[j], codeLabelSeq, codeLabelSeq+19))
    labelValues[j] <- paste(values, labels, collapse ="^", sep="=")
  }
}


labels <- tolower(Labels)
weights <- rep(FALSE, times = length(variableName)) #default to all false, to be calculated later
pvWt <- rep("", times = length(variableName))
Type <- rep("", times = length(variableName))

# For now, assume all variables are characters.
dataType <- rep("character", length(mrcFile))
# Create appropriate data type for variables.
# integer isn't really the right type here, but no way to determine accurate type
# the default of 'character' should be sufficient
dataType[Decimal >0 & Width < 8] <- "integer"
dataType[Decimal >0 & Width >= 8] <- "numeric"

labelValues <- as.character(labelValues)
mrcFileCSV <- data.frame(variableName, Start, End, Width, Decimal, Labels, labelValues, pvWt, Type, dataType, weights, stringsAsFactors=FALSE)
mrcFileCSV <- mrcFileCSV[order(mrcFileCSV$Start),]

write.csv(mrcFileCSV, "mrcFileCSV.csv")
}
