#TODO: it is unclear where theta is

#' @importFrom lsasim block_design booklet_sample booklet_design
gen_cog_items <- function(item_par, booklet, background_data, N = N, theta = "mrpcm1"){
  dim_ib_matrix <- naep_matrix_design(item_par = item_par, booklet = booklet) #columns are booklets, rows are items
  #instead of having block and booklets, I put all the items into booklets, skipped the blocks
  #unique(block$Cog_b2)
  nbooklet <- nrow(booklet)
  #problem is creating block_ex$block assignment - block_design function doesn't accept character item names, only item numbers
  dat_temp <- item_par
  dat_temp$item <- 1:nrow(item_par) #change item names
  dim_ib_matrix_temp <- dim_ib_matrix
  rownames(dim_ib_matrix_temp) <- NULL
  colnames(dim_ib_matrix_temp) <- NULL
  block_ex <- block_design(n_blocks = nbooklet, item_parameters = dat_temp, item_block_matrix = dim_ib_matrix_temp)
  blk_book <- matrix(0, nrow = nbooklet, ncol = nbooklet)
  diag(blk_book) <- 1
  book_ex <- booklet_design(item_block_assignment = block_ex$block_assignment, book_design = blk_book)
  #block_ex$block_assignment and book_ex are the same I may get rid off booklet_design
  #distributing booklets to students
  book_admin <- booklet_sample(n_subj = N, book_item_design = book_ex)
  cognitive_data <- updated_response_gen(subject = book_admin$subject,
                                            item = book_admin$item,
                                            theta = scale(background_data[,theta]), #change the distribution of this theta matrix if it's not normal
                                            a_par = dat_temp$a,
                                            b_par = dat_temp$b,
                                            c_par = dat_temp$c,
                                            d_par = list(dat_temp$d1,
                                                         dat_temp$d2,
                                                         dat_temp$d3,
                                                         dat_temp$d4),
                                            ogive = "Normal")
  colnames(cognitive_data) <- c(item_par$item, "subject")
  cognitive_data$subject <- NULL
  return(cognitive_data)
}
