# library(testthat)
# library(Dire)
# Sys.setenv(NOT_CRAN="")
# test_check('Dire')
