test_that("naepParamTabs works", {
  expect_equal(names(naepParamTabs(NAEPirtparams::parameters)), c("polyParamTab", "dichotParamTab"))
})
