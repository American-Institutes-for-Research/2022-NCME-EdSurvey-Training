library(testthat)
library(NAEPDataSimulation)

test_check("NAEPDataSimulation")
